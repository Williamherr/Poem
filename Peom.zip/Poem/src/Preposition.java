import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Preposition {

    ArrayList<String> prepositions = new ArrayList<>(Arrays.asList("above","across","against","along","among","around",
            "before","behind","beneath","beside","between","beyond","during","inside","onto","outside",
            "under","underneath","upon","with","without","through"));

    public Preposition(){
    }

    public String Rule () {
        int id = (int) (Math.random() * 3);
        String line = "";
        switch (id) {
            case 0:
                //System.out.println("Preposition : new Noun");
                 Noun noun = new Noun();
                 line = noun.Rule();
                 return getPrep() + " " + line;
            case 1:
                //System.out.println("Preposition : new Pronoun");
                 Pronoun pronoun = new Pronoun();
                 line = pronoun.Rule();
                 return getPrep() + " " + line;

            case 2:
                //System.out.println("Preposition : new Adjective");
                Adjective adj = new Adjective();
                line = adj.Rule();
                return getPrep() + " " + line;
        }

        return null;
    }

    public String getPrep() {
        int randomNum = (int) (Math.random() * prepositions.size());
        return prepositions.get(randomNum);
    }
}

