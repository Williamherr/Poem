public class Line {

    public Line() {
    }

    public String Rule () {
        String line = "";
        int id = (int) (Math.random() * 3);
        switch (id) {
            case 0:
                //System.out.println("Line : new Noun");
                Noun noun = new Noun();
                line = noun.Rule();
                break;
            case 1:
               // System.out.println("Line : new Prep");
                Preposition prep = new Preposition();
                line = prep.Rule();
                break;
            case 2:
                //System.out.println("Line : new Pronoun");
                Pronoun pronoun = new Pronoun();
                line = pronoun.Rule();
                break;
        }


        return line + "\n";
    }
}
