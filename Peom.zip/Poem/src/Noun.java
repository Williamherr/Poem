import java.util.ArrayList;
import java.util.Arrays;

public class Noun {

    private ArrayList<String> nouns = new ArrayList<>(Arrays.asList("heart","sun","moon","thunder","fire","time","wind",
            "sea","river","flavor","wave","willow","rain","tree","flower","field","meadow",
            "pasture","harvest","water","father","mother","brother","sister"));

    public Noun() {
    }

    public String Rule () {
        int id = (int) (Math.random() * 3);
        String line = "";
        switch (id) {
            case 0:
                //System.out.println("NOUN : new Verb");
                Verb verb = new Verb();
                line = verb.Rule();
                return getNoun() + " " + line;
            case 1:
                //System.out.println("NOUN : new Prep");
                Preposition prep = new Preposition();
                line = prep.Rule();
                return getNoun() + " " + line;
            case 2:
                //System.out.println("NOUN : END");
                return getNoun();
        }

        return null;
    }

    public String getNoun() {
        int randomNum = (int) (Math.random() * nouns.size());
        return nouns.get(randomNum);
    }

}
