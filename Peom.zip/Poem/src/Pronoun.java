import java.util.ArrayList;
import java.util.Arrays;

public class Pronoun {
    private ArrayList<String> pronouns = new ArrayList<>(Arrays.asList("my","your","his","her"));

    public Pronoun(){
    }

    public String Rule () {
        int id = (int) (Math.random() * 2);
        String line = "";
        switch (id) {
            case 0:
                //System.out.println("pronouns : new Noun");
                Noun noun = new Noun();
                line = noun.Rule();
                return getPronoun() + " " + line;
            case 1:
                //System.out.println("pronouns : new Adj");
                Adjective adj = new Adjective();
                line = adj.Rule();
                return getPronoun() + " " + line;
        }

        return null;
    }
    public String getPronoun() {
        int randomNum = (int) (Math.random() * pronouns.size());
        return pronouns.get(randomNum);
    }
}
