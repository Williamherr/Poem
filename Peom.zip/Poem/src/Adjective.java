import java.util.ArrayList;
import java.util.Arrays;

public class Adjective{
    private ArrayList<String> adjs = new ArrayList<>(Arrays.asList( "black","white","dark","light","bright","murky","muddy","clear"));

    public Adjective() {
    }

    public String Rule () {
        String line = "";
        int id = (int) (Math.random() * 3);
        switch (id) {
            case 0:
                //System.out.println("adj : new Noun");
                Noun noun = new Noun();
                line = noun.Rule();
                return getAdj() + " " + line;
            case 1:
                //System.out.println("adj : new adj");
                Adjective adj = new Adjective();
                line = adj.Rule();
                return getAdj() + " " + line;
            case 2:
                //System.out.println("adj : new End");
                return getAdj();
        }

        return null;
    }

    public String getAdj() {
        int randomNum = (int) (Math.random() * adjs.size());
        return adjs.get(randomNum);
    }
}
