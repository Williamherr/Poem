import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Verb {

    private ArrayList<String> verbs = new ArrayList<>(Arrays.asList("runs","walks","stands","climbs","crawls","flows","flies","transcends","ascends","descends","sinks"));


    public Verb() {
    }

    public String Rule () {
        int id = (int) (Math.random() * 3);
        String line = "";
        switch (id) {
            case 0:
                //System.out.println("Verb : new Preposition");
                Preposition prep = new Preposition();
                line = prep.Rule();
                return getVerb() + " " + line;
            case 1:
                //System.out.println("Verb : new Pronoun");
                Pronoun pronoun = new Pronoun();
                line = pronoun.Rule();
                return getVerb() + " " + line;
            case 2:
                //System.out.println("Verb : new End");
                return getVerb();
        }
        return null;
    }
    public String getVerb() {
        int randomNum = (int) (Math.random() * verbs.size());
        return verbs.get(randomNum);
    }
}
