import java.util.ArrayList;
import java.util.Arrays;

public class Poem {

    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            Line line = new Line();
            line.Rule();
            System.out.print( line.Rule());
        }
    }

}
